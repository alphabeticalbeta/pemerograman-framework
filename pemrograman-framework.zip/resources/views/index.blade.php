@extends('layouts.app')

@section('content')
    <x-home-content :products="$products" />
@endsection
